@echo off
echo Stopping PrintCraft server...
taskkill /F /IM node.exe

echo Stopping Tailscale Funnel...
"C:\Program Files\Tailscale\tailscale.exe" funnel --bg off

echo.
echo Done. All stopped.
timeout /t 2 /nobreak >nul